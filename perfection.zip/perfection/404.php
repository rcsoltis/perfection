 <?php get_header(); ?>

 <!-- Page Content Below -->
 <div id="blog-home" class="container">

     <div class="row">

       
         <div class="col-md-8">

            <h2>Page Not Found</h2>
             <p>I'm sorry, the page you requested is not here. Please use the menu links or the search box on the right.</p>
            


         </div>

         <!-- Sidebar Widgets Column -->
         <div class="col-md-4">

             <?php get_sidebar(); ?>

         </div>

     </div>
     <!-- /.row -->

 </div>
 <!-- /.container -->

 <?php get_footer(); ?>
